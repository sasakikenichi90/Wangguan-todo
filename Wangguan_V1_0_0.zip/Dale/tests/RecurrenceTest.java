package com.dale.todo;
public class RecurrenceTest {
 public static void main(String[] args)throws Exception {
 String[][] cases={{"以后每周三游泳","游泳","每周三"},{"今后每个星期三游个泳","游泳","每周三"},{"往后每星期三游泳","游泳","每周三"},{"每隔2天做实验","做实验","每隔2天"},{"每月15号交房租","交房租","每月15号"},{"以后每天跑步","跑步","每天"},{"以后工作日每天看文献","看文献","每个工作日"},{"下周二吃大白菜","吃大白菜",""}};
 for(String[] x:cases){var a=ExplicitPlan.parse(x[0]);if(a==null||a.size()!=1||!a.get(0).text.equals(x[1])||!a.get(0).repeat.equals(x[2]))throw new AssertionError(x[0]);}
 if(ExplicitPlan.parse("每周一三五跑步")!=null)throw new AssertionError("multi weekday must not silently become Monday");
 if(!TaskTitle.clean("以后每周三游泳").equals("游泳"))throw new AssertionError();
 if(!ExplicitPlan.resolve("每周三","2026-11-18").equals("2026-11-18"))throw new AssertionError();
 System.out.println("RecurrenceTest: 11 passed");
 }
}
