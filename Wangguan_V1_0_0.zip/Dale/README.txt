王冠每日计划 V1.0.0
独立包名 com.wangguan.todo。
更新仓库 sasakikenichi90/Wangguan-todo，公开 Release 直接下载 update.json。
签名使用 WANGGUAN_SIGNING，格式 password:base64(PKCS12)，alias wangguan。
请单独保存签名，勿上传到源码仓库。
