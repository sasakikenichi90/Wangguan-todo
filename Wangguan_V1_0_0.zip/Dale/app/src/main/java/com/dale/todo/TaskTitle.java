package com.dale.todo;
final class TaskTitle {
 static String clean(String s){String t=ExplicitPlan.normalize(s.trim());t=t.replaceFirst("^(?:今天|今日|明天|明日|后天|大后天|每(?:周|星期)[一二三四五六日天]|每月[0-9一二三四五六七八九十两]{1,3}[日号]|每个工作日|工作日每天|每个周末|每(?:隔)?[0-9一二三四五六七八九十两]+天|每天|天天|(?:本|这|下下|下)(?:周|星期)[一二三四五六日天])(?:的)?\\s*", "");t=t.replaceFirst("^(?:上午|下午|晚上|早上|中午)?(?:[0-9一二三四五六七八九十两]+[点时](?:半|[0-9一二三四五六七八九十两]+分)?|[0-9]{1,2}:[0-9]{2})\\s*", "");t=t.replaceFirst("^(?:记得|我要|我想|我打算)\\s*", "");t=t.replaceFirst("^(吃|喝|做|开|打|洗|买)(?:一个|个)(?=.+)", "$1");t=t.replaceFirst("^游(?:个|一下)泳$","游泳");t=t.replaceFirst("^打(?:个|一个)电话$","打电话");return t.trim();}
 static boolean important(String s){return !s.contains("不重要")&&s.matches("(?s).*(重要|务必|必须|一定要|优先完成).*");}
}
